from dataclasses import dataclass


@dataclass
class Dimensions:
    horizontal: int
    veritcal: int
